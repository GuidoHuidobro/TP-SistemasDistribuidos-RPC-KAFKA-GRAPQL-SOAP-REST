export const INVALID_ARGUMENT = 3;
export const NOT_FOUND = 5;
export const FAILED_PRECONDITION = 9;
export const UNAUTHENTICATED = 16;