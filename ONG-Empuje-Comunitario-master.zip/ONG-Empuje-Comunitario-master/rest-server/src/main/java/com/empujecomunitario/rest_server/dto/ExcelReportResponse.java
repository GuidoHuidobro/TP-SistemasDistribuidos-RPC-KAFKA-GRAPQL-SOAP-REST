package com.empujecomunitario.rest_server.dto;

public class ExcelReportResponse {

}
