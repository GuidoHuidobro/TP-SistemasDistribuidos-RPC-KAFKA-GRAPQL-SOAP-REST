package com.empujecomunitario.rest_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
