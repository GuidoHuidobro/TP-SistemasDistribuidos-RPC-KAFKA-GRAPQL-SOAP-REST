package com.grupo_c.SistemasDistribuidosTP.constants;

public enum RoleEnum {
    PRESIDENTE,
    VOCAL,
    COORDINADOR,
    VOLUNTARIO
}
