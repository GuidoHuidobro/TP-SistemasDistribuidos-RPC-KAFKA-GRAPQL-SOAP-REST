package com.grupo_c.SistemasDistribuidosTP.exception.user;

public class UsernameAlreadyExistsException extends Exception {
    public UsernameAlreadyExistsException(String message) {
        super(message);
    }
}
