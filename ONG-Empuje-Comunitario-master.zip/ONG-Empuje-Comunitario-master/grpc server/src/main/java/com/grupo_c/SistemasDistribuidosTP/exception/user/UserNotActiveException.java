package com.grupo_c.SistemasDistribuidosTP.exception.user;

public class UserNotActiveException extends Exception {
    public UserNotActiveException(String message) {
        super(message);
    }
}
