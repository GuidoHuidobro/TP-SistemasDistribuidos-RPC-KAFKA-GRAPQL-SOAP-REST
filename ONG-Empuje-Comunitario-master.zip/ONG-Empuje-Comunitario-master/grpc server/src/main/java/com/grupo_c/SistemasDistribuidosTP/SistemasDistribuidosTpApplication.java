package com.grupo_c.SistemasDistribuidosTP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemasDistribuidosTpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemasDistribuidosTpApplication.class, args);
	}

}
