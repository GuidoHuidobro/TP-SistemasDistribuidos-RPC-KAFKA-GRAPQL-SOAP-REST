package com.grupo_c.SistemasDistribuidosTP.exception.user;

public class InvalidPasswordException extends Exception {
    public InvalidPasswordException(String message) {
        super(message);
    }
}
