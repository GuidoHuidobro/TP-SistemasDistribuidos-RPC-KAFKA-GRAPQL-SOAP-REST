package com.grupo_c.SistemasDistribuidosTP.exception.user;

public class UserNotFoundException extends Exception {
    public UserNotFoundException(String message) {
        super(message);
    }
}
