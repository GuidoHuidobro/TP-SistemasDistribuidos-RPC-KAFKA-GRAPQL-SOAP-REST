package com.grupo_c.SistemasDistribuidosTP.exception.user;

public class EmailAlreadyExistsException extends Exception {
    public EmailAlreadyExistsException(String message) {
        super(message);
    }
}
