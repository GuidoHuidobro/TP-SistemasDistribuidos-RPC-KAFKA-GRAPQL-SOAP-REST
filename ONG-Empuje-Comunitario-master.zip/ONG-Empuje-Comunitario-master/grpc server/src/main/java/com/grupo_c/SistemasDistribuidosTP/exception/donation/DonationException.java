package com.grupo_c.SistemasDistribuidosTP.exception.donation;

public class DonationException extends Exception {
    public DonationException(String message) {
        super(message);
    }
}
