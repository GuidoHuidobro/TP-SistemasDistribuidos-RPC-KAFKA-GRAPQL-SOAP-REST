package com.grupo_c.SistemasDistribuidosTP.exception.user;

public class PhoneNumberAlreadyExistsException extends Exception {
    public PhoneNumberAlreadyExistsException(String message) {
        super(message);
    }
}
