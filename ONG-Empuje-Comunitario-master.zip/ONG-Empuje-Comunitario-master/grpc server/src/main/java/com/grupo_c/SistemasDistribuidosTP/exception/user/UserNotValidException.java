package com.grupo_c.SistemasDistribuidosTP.exception.user;

public class UserNotValidException extends Exception {
    public UserNotValidException(String message) {
        super(message);
    }
}
