package com.grupo_c.SistemasDistribuidosTP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemasDistribuidosTpApplicationTests {

	@Test
	void contextLoads() {
	}

}
